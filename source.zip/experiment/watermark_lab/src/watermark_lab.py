#!/usr/bin/env python3
"""Teaching-grade image watermark and provenance experiment for 24-bit BMP."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import struct
import zlib
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


BMP_HEADER_SIZE = 54
DEFAULT_KEY = "HEU-CS-2027"
REPETITION = 5


@dataclass(slots=True)
class Image:
    width: int
    height: int
    pixels: list[tuple[int, int, int]]

    @property
    def pixel_count(self) -> int:
        return self.width * self.height


@dataclass(slots=True)
class Detection:
    valid: bool
    payload: str
    agreement: float
    minority_groups: int
    confidence: str
    boundary: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _u32(value: int) -> int:
    return value & 0xFFFFFFFF


def write_bmp(path: Path, image: Image) -> None:
    row_stride = (image.width * 3 + 3) & ~3
    pixel_bytes = bytearray(row_stride * image.height)
    for y in range(image.height):
        destination_y = image.height - 1 - y
        for x in range(image.width):
            r, g, b = image.pixels[y * image.width + x]
            offset = destination_y * row_stride + x * 3
            pixel_bytes[offset : offset + 3] = bytes((b, g, r))

    file_size = BMP_HEADER_SIZE + len(pixel_bytes)
    header = bytearray()
    header.extend(b"BM")
    header.extend(struct.pack("<IHHI", file_size, 0, 0, BMP_HEADER_SIZE))
    header.extend(struct.pack("<IiiHHIIiiII", 40, image.width, image.height, 1, 24, 0, len(pixel_bytes), 2835, 2835, 0, 0))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(bytes(header + pixel_bytes))


def read_bmp(path: Path) -> Image:
    data = path.read_bytes()
    if len(data) < BMP_HEADER_SIZE or data[:2] != b"BM":
        raise ValueError("not a BMP file")
    offset = struct.unpack_from("<I", data, 10)[0]
    dib_size = struct.unpack_from("<I", data, 14)[0]
    if dib_size < 40:
        raise ValueError("unsupported DIB header")
    width, height = struct.unpack_from("<ii", data, 18)
    planes, depth = struct.unpack_from("<HH", data, 26)
    compression = struct.unpack_from("<I", data, 30)[0]
    if planes != 1 or depth != 24 or compression != 0:
        raise ValueError("only uncompressed 24-bit BMP is supported")
    if width <= 0 or height == 0:
        raise ValueError("invalid dimensions")

    top_down = height < 0
    height = abs(height)
    row_stride = (width * 3 + 3) & ~3
    pixels: list[tuple[int, int, int]] = []
    for y in range(height):
        source_y = y if top_down else height - 1 - y
        row = offset + source_y * row_stride
        for x in range(width):
            position = row + x * 3
            b, g, r = data[position : position + 3]
            pixels.append((r, g, b))
    return Image(width=width, height=height, pixels=pixels)


def write_ppm(path: Path, image: Image) -> None:
    payload = bytearray(f"P6\n{image.width} {image.height}\n255\n".encode("ascii"))
    for pixel in image.pixels:
        payload.extend(pixel)
    path.write_bytes(bytes(payload))


def procedural_source(width: int = 320, height: int = 200) -> Image:
    pixels: list[tuple[int, int, int]] = []
    for y in range(height):
        for x in range(width):
            sky_r = int(18 + 80 * y / height)
            sky_g = int(44 + 100 * y / height)
            sky_b = int(74 + 110 * y / height)
            wave = int(12 * math.sin((x + y * 0.7) / 18))
            r, g, b = sky_r + wave, sky_g + wave, sky_b + wave

            # A simple ship-shaped polygon keeps the exercise local to HEU.
            if 95 <= y <= 126 and 65 <= x <= 262:
                deck = (x - 65) / 197
                hull_top = 101
                hull_bottom = int(118 - 15 * math.sin(math.pi * deck))
                if hull_top <= y <= hull_bottom:
                    r, g, b = 54, 69, 83
            if 76 <= y <= 117 and 132 <= x <= 221:
                r, g, b = 218, 223, 227
            if 69 <= y <= 76 and 170 <= x <= 196:
                r, g, b = 221, 179, 91
            if 80 <= y <= 97:
                for cx in (142, 167, 192, 211):
                    if cx - 5 <= x <= cx + 5:
                        r, g, b = 38, 74, 104

            noise = ((x * 31 + y * 17) % 7) - 3
            pixels.append(
                (
                    max(0, min(255, r + noise)),
                    max(0, min(255, g + noise)),
                    max(0, min(255, b + noise)),
                )
            )
    return Image(width, height, pixels)


def _payload_bits(payload: str) -> tuple[list[int], bytes]:
    raw = payload.encode("utf-8")
    length = struct.pack("<H", len(raw))
    checksum = struct.pack("<I", zlib.crc32(raw) & 0xFFFFFFFF)
    framed = length + raw + checksum
    bits: list[int] = []
    for value in framed:
        for shift in range(7, -1, -1):
            bit = (value >> shift) & 1
            bits.extend([bit] * REPETITION)
    return bits, raw


def _positions(width: int, height: int, count: int, key: str) -> list[int]:
    total = width * height
    if count > total:
        raise ValueError("capacity exceeded")
    seed = int.from_bytes(hashlib.sha256(key.encode("utf-8")).digest()[:8], "big")
    rng = random.Random(seed)
    return rng.sample(range(total), count)


def embed(source: Image, payload: str, key: str = DEFAULT_KEY) -> tuple[Image, dict[str, object]]:
    bits, raw = _payload_bits(payload)
    positions = _positions(source.width, source.height, len(bits), key)
    pixels = list(source.pixels)
    for frame_index, position in enumerate(positions):
        r, g, b = pixels[position]
        b = (b & 0xFE) | bits[frame_index]
        pixels[position] = (r, g, b)
    marked = Image(source.width, source.height, pixels)
    return marked, {
        "payload_bytes": len(raw),
        "encoded_bits": len(bits),
        "repetition": REPETITION,
        "key_fingerprint": hashlib.sha256(key.encode("utf-8")).hexdigest()[:16],
    }


def _extract_scan(image: Image, bit_count: int, key: str) -> list[int]:
    positions = _positions(image.width, image.height, bit_count, key)
    return [image.pixels[position][2] & 1 for position in positions]


def verify(image: Image, key: str = DEFAULT_KEY) -> Detection:
    # Read and majority-decode the length prefix.
    prefix = _extract_scan(image, 16 * REPETITION, key)
    grouped = _decode_groups(prefix)
    prefix_bytes = _bits_to_bytes(grouped)
    length = struct.unpack("<H", prefix_bytes)[0]
    if length <= 0 or length > 1024:
        return Detection(False, "", 0.0, 0, "低", "帧长度不合理，可能无标识或密钥不匹配。")

    total_bits = (2 + length + 4) * 8 * REPETITION
    samples = _extract_scan(image, total_bits, key)
    groups = [
        samples[index : index + REPETITION]
        for index in range(0, len(samples), REPETITION)
    ]
    decoded_bits = _decode_groups(samples)
    frame_bytes = _bits_to_bytes(decoded_bits)
    if len(frame_bytes) < 2 + length + 4:
        return Detection(False, "", 0.0, 0, "低", "载荷不完整。")
    raw = bytes(frame_bytes[2 : 2 + length])
    expected = struct.unpack("<I", bytes(frame_bytes[2 + length : 2 + length + 4]))[0]
    actual = zlib.crc32(raw) & 0xFFFFFFFF
    agreement = sum(max(bit.count(0), bit.count(1)) for bit in groups) / (
        len(groups) * REPETITION
    )
    minority_groups = sum(
        1 for bit in groups if 0 < bit.count(0) < REPETITION
    )
    if expected != actual:
        return Detection(
            False,
            raw.decode("utf-8", "replace"),
            agreement,
            minority_groups,
            "中",
            "CRC不一致。",
        )
    confidence = "高" if agreement >= 0.96 else "中"
    return Detection(
        True,
        raw.decode("utf-8", "replace"),
        agreement,
        minority_groups,
        confidence,
        f"载荷通过{REPETITION}次重复码与CRC校验。",
    )


def _decode_groups(samples: list[int]) -> list[int]:
    result: list[int] = []
    for index in range(0, len(samples), REPETITION):
        group = samples[index : index + REPETITION]
        result.append(0 if group.count(0) >= group.count(1) else 1)
    return result


def _bits_to_bytes(bits: list[int]) -> bytearray:
    result = bytearray()
    for index in range(0, len(bits) - len(bits) % 8, 8):
        value = 0
        for bit in bits[index : index + 8]:
            value = (value << 1) | bit
        result.append(value)
    return result


def attack(
    image: Image,
    brightness: int = 3,
    noise_bits: int = 1,
    noise_rate: float = 0.05,
    seed: int = 17,
) -> Image:
    rng = random.Random(seed)
    pixels: list[tuple[int, int, int]] = []
    for r, g, b in image.pixels:
        g = max(0, min(255, g + brightness))
        r = max(0, min(255, r + rng.randint(-1, 1)))
        if noise_bits > 0 and rng.random() < noise_rate:
            b = b ^ (1 << rng.randint(0, noise_bits - 1))
        pixels.append((r, g, b))
    return Image(image.width, image.height, pixels)


def psnr(first: Image, second: Image) -> float:
    if first.width != second.width or first.height != second.height:
        raise ValueError("images must have identical size")
    total = 0
    count = 0
    for left, right in zip(first.pixels, second.pixels):
        for a, b in zip(left, right):
            total += (a - b) ** 2
            count += 1
    mse = total / count
    return float("inf") if mse == 0 else 10 * math.log10((255**2) / mse)


def _demo(output: Path) -> dict[str, object]:
    output.mkdir(parents=True, exist_ok=True)
    source = procedural_source()
    payload = "HEUYIZHOU:AIGC:COURSE:DEMO"
    marked, embed_meta = embed(source, payload)
    attacked = attack(marked)
    result = verify(attacked)

    write_bmp(output / "source.bmp", source)
    write_bmp(output / "marked.bmp", marked)
    write_bmp(output / "attacked.bmp", attacked)
    write_ppm(output / "source.ppm", source)
    write_ppm(output / "marked.ppm", marked)
    write_ppm(output / "attacked.ppm", attacked)

    report = {
        "schema": "watermark-lab.result.v1",
        "payload_expected": payload,
        "embed": embed_meta,
        "detection": result.to_dict(),
        "quality": {
            "source_to_marked_psnr_db": round(psnr(source, marked), 4),
            "marked_to_attacked_psnr_db": round(psnr(marked, attacked), 4),
        },
        "data_note": "procedural teaching image; no real person or restricted vessel image",
    }
    (output / "result.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    demo_parser = sub.add_parser("demo")
    demo_parser.add_argument("--output", type=Path, default=Path("outputs"))
    verify_parser = sub.add_parser("verify")
    verify_parser.add_argument("image", type=Path)
    verify_parser.add_argument("--key", default=DEFAULT_KEY)
    args = parser.parse_args()
    if args.command == "demo":
        report = _demo(args.output)
        print(json.dumps(report, ensure_ascii=False, indent=2))
    elif args.command == "verify":
        print(json.dumps(verify(read_bmp(args.image), args.key).to_dict(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

