#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "outputs"
FONT = "/System/Library/Fonts/Supplemental/Songti.ttc"


def font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT, size=size)


def fit(image: Image.Image, width: int, height: int) -> Image.Image:
    copy = image.copy()
    copy.thumbnail((width, height), Image.Resampling.LANCZOS)
    canvas = Image.new("RGB", (width, height), "#101820")
    x = (width - copy.width) // 2
    y = (height - copy.height) // 2
    canvas.paste(copy, (x, y))
    return canvas


def main() -> None:
    report = json.loads((OUTPUT / "result.json").read_text(encoding="utf-8"))
    source = Image.open(OUTPUT / "source.ppm").convert("RGB")
    marked = Image.open(OUTPUT / "marked.ppm").convert("RGB")
    attacked = Image.open(OUTPUT / "attacked.ppm").convert("RGB")
    source.save(OUTPUT / "source.png")
    marked.save(OUTPUT / "marked.png")
    attacked.save(OUTPUT / "attacked.png")
    diff = ImageChops.difference(source, marked)
    diff = diff.point(lambda value: min(255, value * 24))

    width, height = 2280, 1040
    canvas = Image.new("RGB", (width, height), "#f3f5f7")
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((0, 0, width, 132), fill="#102d4d")
    draw.text((74, 38), "AIGC 图像可信标识实验", font=font(44), fill="#ffffff")
    draw.text(
        (77, 92),
        "哈尔滨工程大学 · 计算机学院  |  LSB、校验与攻击验证",
        font=font(20),
        fill="#aebdd0",
    )

    panels = [
        ("原始图像", fit(source, 500, 330)),
        ("嵌入课程标识", fit(marked, 500, 330)),
        ("亮度与通道噪声攻击", fit(attacked, 500, 330)),
        ("LSB差异 ×24", fit(diff, 500, 330)),
    ]
    x = 70
    for title, image in panels:
        draw.text((x, 170), title, font=font(22), fill="#25364a")
        draw.rectangle((x, 213, x + 500, 543), outline="#c6d0da", width=2)
        canvas.paste(image, (x, 213))
        x += 535

    detection = report["detection"]
    quality = report["quality"]
    cards = [
        ("载荷校验", "通过" if detection["valid"] else "未通过", "#1f7a70"),
        ("重复码一致率", f'{detection["agreement"] * 100:.1f}%', "#246fa8"),
        ("嵌入后 PSNR", f'{quality["source_to_marked_psnr_db"]:.2f} dB', "#b47419"),
        ("攻击后 PSNR", f'{quality["marked_to_attacked_psnr_db"]:.2f} dB', "#5d6b7c"),
    ]
    x = 70
    for label, value, color in cards:
        draw.rounded_rectangle(
            (x, 610, x + 390, 760),
            radius=12,
            fill="#ffffff",
            outline="#d0d7df",
            width=2,
        )
        draw.text((x + 28, 635), label, font=font(20), fill="#647286")
        draw.text((x + 28, 685), value, font=font(38), fill=color)
        x += 420

    draw.text((70, 817), "检测结论", font=font(27), fill="#19324e")
    conclusion = (
        f'提取载荷：{detection["payload"]}。'
        f'{detection["boundary"]}本实验只证明指定攻击下的教学级可恢复性，'
        "不能替代生产级版权保护或生成内容来源认定。"
    )
    draw.multiline_text(
        (70, 863),
        conclusion,
        font=font(22),
        fill="#36485c",
        spacing=12,
    )
    draw.line((70, 976, width - 70, 976), fill="#c7d0d9", width=2)
    draw.text(
        (70, 993),
        "代码可复现 · 固定随机种子 · 图像由程序生成 · 不含真实学生或受限装备数据",
        font=font(18),
        fill="#758293",
    )
    target = OUTPUT / "verification_contact_sheet.png"
    canvas.save(target, quality=95)
    print(target)


if __name__ == "__main__":
    main()

