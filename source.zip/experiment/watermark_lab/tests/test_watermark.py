from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import sys


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from watermark_lab import (  # noqa: E402
    attack,
    embed,
    procedural_source,
    psnr,
    read_bmp,
    verify,
    write_bmp,
)


class WatermarkTests(unittest.TestCase):
    def test_roundtrip_and_attack(self) -> None:
        source = procedural_source(160, 100)
        marked, _ = embed(source, "HEU:COURSE:AIGC:TEST")
        attacked = attack(marked, brightness=2, noise_bits=1)
        result = verify(attacked)
        self.assertTrue(result.valid)
        self.assertEqual(result.payload, "HEU:COURSE:AIGC:TEST")
        self.assertGreater(result.agreement, 0.85)
        self.assertGreater(psnr(source, marked), 45)

    def test_wrong_key_fails_safely(self) -> None:
        source = procedural_source(96, 64)
        marked, _ = embed(source, "HEU:SECRET", key="right-key")
        result = verify(marked, key="wrong-key")
        self.assertFalse(result.valid)

    def test_bmp_roundtrip(self) -> None:
        source = procedural_source(64, 48)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "image.bmp"
            write_bmp(path, source)
            restored = read_bmp(path)
        self.assertEqual(restored.width, source.width)
        self.assertEqual(restored.height, source.height)
        self.assertEqual(restored.pixels[:20], source.pixels[:20])


if __name__ == "__main__":
    unittest.main()

