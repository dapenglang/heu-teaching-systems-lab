#!/usr/bin/env python3
from __future__ import annotations

import base64
import mimetypes
import re
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
DOCS = ROOT / "docs"
DEPLOY = ROOT / "deploy"


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def main() -> None:
    DEPLOY.mkdir(parents=True, exist_ok=True)
    html = (DOCS / "index.html").read_text(encoding="utf-8")
    css = (DOCS / "github-pages.css").read_text(encoding="utf-8")
    js = (DOCS / "github-pages.js").read_text(encoding="utf-8")
    html = html.replace("./github-pages.css", "./site.css")
    html = html.replace("./github-pages.js", "./site.js")
    html = re.sub(r'\./assets/([^"]+)', r'./\1', html)
    (DEPLOY / "index.html").write_text(html, encoding="utf-8")
    (DEPLOY / "site.css").write_text(css, encoding="utf-8")
    (DEPLOY / "site.js").write_text(js, encoding="utf-8")
    for asset in (DOCS / "assets").iterdir():
        if asset.is_file():
            shutil.copy2(asset, DEPLOY / asset.name)
    shutil.copy2(ROOT / "README.md", DEPLOY / "README.md")
    print(DEPLOY / "index.html")
    print(DEPLOY / "README.md")


if __name__ == "__main__":
    main()

