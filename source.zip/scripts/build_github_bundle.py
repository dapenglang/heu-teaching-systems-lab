#!/usr/bin/env python3
from __future__ import annotations

import base64
import mimetypes
import re
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
DOCS = ROOT / "docs"
DEPLOY = ROOT / "deploy"


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def main() -> None:
    DEPLOY.mkdir(parents=True, exist_ok=True)
    html = (DOCS / "index.html").read_text(encoding="utf-8")
    css = (DOCS / "github-pages.css").read_text(encoding="utf-8")
    js = (DOCS / "github-pages.js").read_text(encoding="utf-8")

    html = html.replace(
        '<link rel="stylesheet" href="./github-pages.css">',
        f"<style>\n{css}\n</style>",
    )
    html = html.replace(
        '<script src="./github-pages.js"></script>',
        f"<script>\n{js}\n</script>",
    )

    def replace_asset(match: re.Match[str]) -> str:
        relative = match.group(1)
        path = DOCS / relative.lstrip("./")
        if not path.exists():
            return match.group(0)
        return f'src="{data_uri(path)}"'

    html = re.sub(r'src="(\./assets/[^"]+)"', replace_asset, html)
    (DEPLOY / "index.html").write_text(html, encoding="utf-8")
    shutil.copy2(ROOT / "README.md", DEPLOY / "README.md")
    print(DEPLOY / "index.html")
    print(DEPLOY / "README.md")


if __name__ == "__main__":
    main()

