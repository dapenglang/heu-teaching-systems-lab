#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "application"
OUT = APP / "送审稿"
OUT.mkdir(parents=True, exist_ok=True)

BLACK = RGBColor(0, 0, 0)
NAVY = "173B68"
HEADER_BLUE = "173B68"
PALE_BLUE = "EEF3F8"
GRID = "D9D9D9"
BODY_CN = "Songti SC"
BODY_EN = "Times New Roman"


DOCS = [
    {
        "source": APP / "A_问数航标_教学创新赛材料初稿.md",
        "output": OUT / "A_问数航标_全国高校教师教学创新大赛_送审稿.docx",
        "title": "问数航标",
        "subtitle": "面向真实数据任务的Python大数据分析课程人机协同教学创新",
        "metadata": [
            ("申报赛事", "全国高校教师教学创新大赛人工智能赛道"),
            ("主讲教师", "郎大鹏"),
            ("所在单位", "哈尔滨工程大学计算机学院"),
            ("材料状态", "送审工作稿"),
        ],
        "figures": [],
    },
    {
        "source": APP / "B_译舟_AI教学赛道作品介绍初稿.md",
        "output": OUT / "B_译舟_AI+教育创新应用技能大赛_送审稿.docx",
        "title": "译舟",
        "subtitle": "跨专业Python课程的可信反馈教学智能体",
        "metadata": [
            ("申报赛事", "AI+教育创新应用技能大赛"),
            ("申报组别", "高等教育组 AI+教学赛道"),
            ("项目负责人", "郎大鹏"),
            ("材料状态", "送审工作稿"),
        ],
        "figures": [
            (
                "图1  引导修复界面",
                ROOT / "docs" / "assets" / "feedback-trace.png",
            ),
            (
                "图2  班级学习脉冲与教师关注队列",
                ROOT / "docs" / "assets" / "class-pulse.png",
            ),
        ],
    },
    {
        "source": APP / "C_像素证签_实验案例初稿.md",
        "output": OUT / "C_像素证签_全国计算机实验教学案例评选_送审稿.docx",
        "title": "像素证签",
        "subtitle": "面向AIGC图像标识与篡改检测的位操作综合实验",
        "metadata": [
            ("申报赛事", "全国计算机类课程实验教学案例评选"),
            ("实验课程", "计算思维与问题求解"),
            ("案例主持人", "郎大鹏"),
            ("材料状态", "送审工作稿"),
        ],
        "figures": [
            (
                "图1  原始图像、嵌入图像、攻击图像与差异图",
                ROOT / "docs" / "assets" / "verification_contact_sheet.png",
            )
        ],
    },
]


def set_run_font(run, size: float | None = None, bold: bool | None = None) -> None:
    run.font.name = BODY_EN
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), BODY_EN)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), BODY_EN)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), BODY_CN)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold


def set_cell_shading(cell, fill: str) -> None:
    properties = cell._tc.get_or_add_tcPr()
    shading = properties.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        properties.append(shading)
    shading.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=65, start=100, bottom=65, end=100) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), GRID)


def mark_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    header = tr_pr.find(qn("w:tblHeader"))
    if header is None:
        header = OxmlElement("w:tblHeader")
        tr_pr.append(header)
    header.set(qn("w:val"), "true")


def add_page_number(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = "PAGE"
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)


def configure_document(doc: Document, header_text: str) -> None:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.78)
    section.bottom_margin = Inches(0.78)
    section.left_margin = Inches(0.88)
    section.right_margin = Inches(0.88)
    section.header_distance = Inches(0.35)
    section.footer_distance = Inches(0.35)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = BODY_EN
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_CN)
    normal.font.size = Pt(11.5)
    normal.font.color.rgb = BLACK
    normal.paragraph_format.line_spacing = 1.5
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.first_line_indent = Pt(23)

    for style_name, size in (("Heading 1", 18), ("Heading 2", 14.5), ("Heading 3", 12)):
        style = styles[style_name]
        style.font.name = BODY_EN
        style._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_CN)
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = BLACK
        style.paragraph_format.space_before = Pt(16 if style_name == "Heading 1" else 11)
        style.paragraph_format.space_after = Pt(7)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.first_line_indent = Pt(0)

    title = styles["Title"]
    title.font.name = BODY_EN
    title._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_CN)
    title.font.size = Pt(38)
    title.font.bold = True
    title.font.color.rgb = BLACK
    title.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    title.paragraph_format.space_after = Pt(8)
    title_ppr = title._element.get_or_add_pPr()
    for border in list(title_ppr.findall(qn("w:pBdr"))):
        title_ppr.remove(border)

    header = section.header
    header_paragraph = header.paragraphs[0]
    header_paragraph.text = ""
    header_run = header_paragraph.add_run(header_text)
    set_run_font(header_run, 9)
    header_run.font.color.rgb = RGBColor(105, 115, 128)

    add_page_number(section.footer.paragraphs[0])


def add_cover(doc: Document, spec: dict) -> None:
    accent = doc.add_paragraph()
    accent.paragraph_format.space_before = Pt(24)
    accent.paragraph_format.space_after = Pt(42)
    accent_run = accent.add_run("■")
    set_run_font(accent_run, 12, True)
    accent_run.font.color.rgb = RGBColor.from_string(NAVY)

    title = doc.add_paragraph(style="Title")
    title.add_run(spec["title"])
    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.first_line_indent = Pt(0)
    subtitle.paragraph_format.space_after = Pt(64)
    subtitle_text = spec["subtitle"]
    split_at = subtitle_text.find("课程") + 2 if "课程" in subtitle_text else -1
    if split_at > 4:
        first = subtitle.add_run(subtitle_text[:split_at])
        set_run_font(first, 17)
        first.add_break()
        second = subtitle.add_run(subtitle_text[split_at:])
        set_run_font(second, 17)
    else:
        subtitle_run = subtitle.add_run(subtitle_text)
        set_run_font(subtitle_run, 17)

    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    table.columns[0].width = Inches(1.25)
    table.columns[1].width = Inches(4.55)
    set_table_borders(table)
    for key, value in spec["metadata"]:
        cells = table.add_row().cells
        cells[0].width = Inches(1.25)
        cells[1].width = Inches(4.55)
        for cell in cells:
            set_cell_margins(cell, 120, 130, 120, 130)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        cells[0].text = key
        cells[1].text = value
        set_cell_shading(cells[0], PALE_BLUE)
        for run in cells[0].paragraphs[0].runs:
            set_run_font(run, 10.5, True)
        for run in cells[1].paragraphs[0].runs:
            set_run_font(run, 10.5)
    if table.rows:
        mark_table_header(table.rows[0])
    doc.add_page_break()


def add_table(doc: Document, rows: list[list[str]]) -> None:
    if not rows:
        return
    columns = max(len(row) for row in rows)
    table = doc.add_table(rows=len(rows), cols=columns)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    set_table_borders(table)
    mark_table_header(table.rows[0])
    for row_index, row in enumerate(rows):
        for column_index in range(columns):
            cell = table.cell(row_index, column_index)
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cell.text = row[column_index].strip() if column_index < len(row) else ""
            if row_index == 0:
                set_cell_shading(cell, HEADER_BLUE)
                for run in cell.paragraphs[0].runs:
                    set_run_font(run, 9.6, True)
                    run.font.color.rgb = RGBColor(255, 255, 255)
            else:
                if row_index % 2 == 0:
                    set_cell_shading(cell, PALE_BLUE)
                for run in cell.paragraphs[0].runs:
                    set_run_font(run, 9.6)
    doc.add_paragraph().paragraph_format.space_after = Pt(3)


def add_figure(doc: Document, caption: str, image_path: Path) -> None:
    if not image_path.exists():
        return
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.first_line_indent = Pt(0)
    run = paragraph.add_run()
    inline_shape = run.add_picture(str(image_path), width=Inches(6.35))
    doc_pr = inline_shape._inline.docPr
    doc_pr.set("descr", caption)
    doc_pr.set("title", caption)
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.first_line_indent = Pt(0)
    cap_run = cap.add_run(caption)
    set_run_font(cap_run, 9)
    cap_run.font.color.rgb = RGBColor(100, 109, 122)


def parse_markdown(path: Path) -> list[tuple[str, object]]:
    lines = path.read_text(encoding="utf-8").splitlines()
    blocks: list[tuple[str, object]] = []
    paragraph: list[str] = []
    table_rows: list[list[str]] = []

    def flush_paragraph() -> None:
        nonlocal paragraph
        if paragraph:
            blocks.append(("paragraph", " ".join(item.strip() for item in paragraph)))
            paragraph = []

    def flush_table() -> None:
        nonlocal table_rows
        if table_rows:
            useful = [
                row
                for row in table_rows
                if not all(re.fullmatch(r":?-{3,}:?", cell.strip()) for cell in row)
            ]
            blocks.append(("table", useful))
            table_rows = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("|") and stripped.endswith("|"):
            flush_paragraph()
            table_rows.append([cell.strip() for cell in stripped.strip("|").split("|")])
            continue
        flush_table()
        if not stripped:
            flush_paragraph()
        elif stripped.startswith("### "):
            flush_paragraph()
            blocks.append(("h3", stripped[4:]))
        elif stripped.startswith("## "):
            flush_paragraph()
            blocks.append(("h2", stripped[3:]))
        elif stripped.startswith("# "):
            flush_paragraph()
            blocks.append(("h1", stripped[2:]))
        elif stripped.startswith("> "):
            flush_paragraph()
            blocks.append(("note", stripped[2:]))
        elif re.match(r"^\d+\.\s+", stripped):
            flush_paragraph()
            blocks.append(("ordered", stripped))
        elif stripped.startswith("- "):
            flush_paragraph()
            blocks.append(("bullet", stripped[2:]))
        elif stripped.startswith("```"):
            continue
        else:
            paragraph.append(stripped)
    flush_paragraph()
    flush_table()
    return blocks


def build(spec: dict) -> Path:
    doc = Document()
    configure_document(doc, f'{spec["title"]}  |  哈尔滨工程大学计算机学院')
    add_cover(doc, spec)

    blocks = parse_markdown(spec["source"])
    # The markdown title and subtitle are represented on the cover.
    body_started = False
    figure_inserted = False
    evidence_table_pending = False
    for kind, value in blocks:
        if kind == "h1" and value == spec["title"]:
            continue
        if kind in {"h1", "h2"} and value == spec["subtitle"]:
            continue
        if not body_started:
            if kind == "h2":
                body_started = True
            else:
                continue
        if (
            spec["title"] == "像素证签"
            and kind == "h2"
            and str(value).startswith("七、")
        ):
            doc.add_page_break()
        if (
            spec["title"] == "问数航标"
            and kind == "h2"
            and str(value).startswith("五、")
        ):
            doc.add_page_break()
        if (
            spec["title"] == "问数航标"
            and kind == "h2"
            and str(value).startswith("六、")
        ):
            evidence_table_pending = True
        if (
            not figure_inserted
            and kind == "h2"
            and "创新点" in str(value)
            and spec["title"] == "译舟"
        ):
            doc.add_heading("界面与应用证据", level=2)
            for caption, image in spec["figures"]:
                add_figure(doc, caption, image)
            figure_inserted = True
        if kind == "h1":
            doc.add_heading(str(value), level=1)
        elif kind == "h2":
            doc.add_heading(str(value), level=2)
        elif kind == "h3":
            doc.add_heading(str(value), level=3)
        elif kind == "paragraph":
            paragraph = doc.add_paragraph(str(value))
        elif kind == "bullet":
            paragraph = doc.add_paragraph(style="List Bullet")
            paragraph.paragraph_format.first_line_indent = Pt(0)
            paragraph.add_run(str(value))
        elif kind == "ordered":
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.first_line_indent = Pt(0)
            paragraph.paragraph_format.left_indent = Pt(12)
            paragraph.add_run(str(value))
        elif kind == "note":
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.first_line_indent = Pt(0)
            run = paragraph.add_run(str(value))
            set_run_font(run, 10.5)
            run.italic = True
            run.font.color.rgb = RGBColor(83, 96, 112)
        elif kind == "table":
            if evidence_table_pending:
                doc.add_page_break()
                evidence_table_pending = False
            add_table(doc, value)

        if not figure_inserted and (
            (kind == "h2" and "真实应用" in str(value))
            or (kind == "h1" and "应用场景" in str(value))
            or (kind == "h2" and "参考实现" in str(value))
        ):
            for caption, image in spec["figures"]:
                add_figure(doc, caption, image)
            figure_inserted = True

    # Make paragraph fonts explicit after construction.
    for paragraph in doc.paragraphs:
        if paragraph.style.name.startswith("Heading") or paragraph.style.name == "Title":
            for run in paragraph.runs:
                set_run_font(run)
                run.font.color.rgb = BLACK
        else:
            for run in paragraph.runs:
                set_run_font(run)

    doc.core_properties.title = f'{spec["title"]}：{spec["subtitle"]}'
    doc.core_properties.subject = "教学竞赛送审工作稿"
    doc.core_properties.author = "郎大鹏"
    doc.core_properties.keywords = "教学创新, Python, 可信AI, AIGC, 实验教学"
    doc.save(spec["output"])
    return spec["output"]


def main() -> None:
    for spec in DOCS:
        path = build(spec)
        print(path)


if __name__ == "__main__":
    main()

