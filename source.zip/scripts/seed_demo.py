#!/usr/bin/env python3
from __future__ import annotations

import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from yizhou_lab.storage import EventStore  # noqa: E402


ERRORS = [
    ("KeyError", "字典计数与缺省值", 0.25),
    ("TypeError", "数据类型与类型转换", 0.17),
    ("ValueError", "数据清洗与缺失值", 0.13),
    ("UnicodeDecodeError", "文本编码与中文数据处理", 0.11),
    ("FileNotFoundError", "文件读写与路径管理", 0.10),
    ("IndexError", "条件、循环与程序控制", 0.09),
    ("ResultMismatch", "结果验证与边界测试", 0.09),
    ("ModuleNotFoundError", "模块、依赖与项目结构", 0.06),
]


def main() -> None:
    db_path = ROOT / "var" / "yizhou.sqlite3"
    store = EventStore(db_path)
    removed = store.clear_origin("SYNTHETIC_DEMO")
    rng = random.Random(20261113)
    start = datetime(2026, 2, 23, 8, 0, tzinfo=timezone.utc)
    students = [f"S{i:02d}" for i in range(1, 37)]
    ability = {
        student: max(0.52, min(0.95, rng.gauss(0.78, 0.11)))
        for student in students
    }
    event_count = 0
    for week in range(1, 15):
        for student in students:
            if rng.random() > 0.58:
                continue
            for _ in range(rng.choice([1, 1, 1, 2])):
                error_type, knowledge_point, _ = rng.choices(
                    ERRORS,
                    weights=[item[2] for item in ERRORS],
                    k=1,
                )[0]
                base = ability[student] + min(0.11, week * 0.008)
                difficulty = 0.08 if error_type in {"KeyError", "ResultMismatch"} else 0.03
                resolved = rng.random() < max(0.45, base - difficulty)
                review_confirmed = rng.random() < (0.79 if resolved else 0.43)
                hint_level = rng.choices(
                    [1, 2, 3, 4],
                    weights=[0.31, 0.40, 0.21, 0.08],
                    k=1,
                )[0]
                if error_type == "ResultMismatch" and rng.random() < 0.35:
                    hint_level = 4
                created_at = start + timedelta(
                    days=(week - 1) * 7 + rng.randint(0, 4),
                    hours=rng.randint(0, 10),
                    minutes=rng.randint(0, 59),
                )
                store.add_event(
                    {
                        "created_at": created_at.isoformat(),
                        "student_id": student,
                        "course_id": "python-data",
                        "function_name": rng.choice(
                            ["socratic-repair", "error-trace", "boundary-review"]
                        ),
                        "knowledge_point": knowledge_point,
                        "error_type": error_type,
                        "hint_level": hint_level,
                        "resolved": resolved,
                        "review_confirmed": review_confirmed,
                        "ai_used": True,
                        "data_origin": "SYNTHETIC_DEMO",
                        "payload": {
                            "dataset": "fixed-seed functional demonstration",
                            "week": week,
                        },
                    }
                )
                event_count += 1
    print(
        f"seeded {event_count} synthetic demo events; replaced {removed}; database={db_path}"
    )


if __name__ == "__main__":
    main()

