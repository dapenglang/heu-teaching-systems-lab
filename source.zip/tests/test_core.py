from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from yizhou_lab.analytics import summarize
from yizhou_lab.curriculum import CurriculumGraph
from yizhou_lab.models import FeedbackRequest
from yizhou_lab.provenance import digest
from yizhou_lab.storage import EventStore
from yizhou_lab.tutor import generate_feedback


ROOT = Path(__file__).resolve().parent.parent


class TutorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.graph = CurriculumGraph(ROOT / "data" / "course_graph.json")

    def test_key_error_maps_to_counting_skill(self) -> None:
        request = FeedbackRequest(
            student_id="S01",
            code="for word in words:\n    counts[word] += 1",
            error="KeyError: 'the'",
        )
        result = generate_feedback(request, self.graph)
        self.assertEqual(result.diagnosis.error_type, "KeyError")
        self.assertEqual(result.diagnosis.knowledge_point_id, "dict-count")
        self.assertGreaterEqual(result.diagnosis.confidence, 0.9)

    def test_feedback_does_not_supply_complete_answer(self) -> None:
        request = FeedbackRequest(
            student_id="S01",
            code="counts[word] += 1",
            error="KeyError: 'the'",
        )
        result = generate_feedback(request, self.graph)
        joined = "\n".join(result.hint_ladder)
        self.assertNotIn("counts[word] = counts.get(word, 0) + 1", joined)
        self.assertGreaterEqual(len(result.self_check), 3)
        self.assertEqual(len(result.review_checklist), 4)

    def test_provenance_digest_is_stable(self) -> None:
        value = {"b": 2, "a": 1}
        self.assertEqual(digest(value), digest({"a": 1, "b": 2}))


class StorageTests(unittest.TestCase):
    def test_export_and_analytics(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            store = EventStore(root / "events.db")
            for index in range(6):
                store.add_event(
                    {
                        "student_id": f"S{index % 2 + 1:02d}",
                        "knowledge_point": "字典计数与缺省值",
                        "error_type": "KeyError" if index < 4 else "TypeError",
                        "hint_level": 2 + index % 2,
                        "resolved": index != 2,
                        "review_confirmed": index > 2,
                        "data_origin": "TEST_ONLY",
                    }
                )
            analytics = summarize(store.list_events())
            self.assertEqual(analytics["total_events"], 6)
            self.assertEqual(analytics["student_count"], 2)
            self.assertEqual(analytics["error_hotspots"][0]["name"], "KeyError")
            target = root / "export.json"
            store.export(target)
            self.assertTrue(target.exists())
            self.assertIn("yizhou.evidence-export.v1", target.read_text("utf-8"))


if __name__ == "__main__":
    unittest.main()

