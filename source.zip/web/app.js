const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

const samples = {
  keyerror: {
    code: "for word in words:\n    counts[word] += 1",
    error: "KeyError: 'the'",
  },
  encoding: {
    code: "with open(path) as handle:\n    text = handle.read()",
    error: "UnicodeDecodeError: 'utf-8' codec can't decode byte 0xd0 in position 12",
  },
  path: {
    code: "with open('data/news.csv') as handle:\n    rows = handle.readlines()",
    error: "FileNotFoundError: [Errno 2] No such file or directory",
  },
};

function text(tag, value, className = "") {
  const node = document.createElement(tag);
  if (className) node.className = className;
  node.textContent = value;
  return node;
}

function setTab(name) {
  $$(".tab").forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.tab === name);
  });
  $$(".tab-panel").forEach((panel) => {
    panel.classList.toggle("active", panel.id === `tab-${name}`);
  });
  if (name === "pulse") loadAnalytics();
  if (name === "evidence") loadCourse();
}

$$(".tab").forEach((tab) => {
  tab.addEventListener("click", () => setTab(tab.dataset.tab));
});

$$(".sample").forEach((button) => {
  button.addEventListener("click", () => {
    const sample = samples[button.dataset.sample];
    $("#code-input").value = sample.code;
    $("#error-input").value = sample.error;
    $("#form-message").textContent = "";
  });
});

function renderPath(path) {
  const container = $("#feedback-content .path-strip");
  container.replaceChildren();
  path.forEach((item, index) => {
    if (index) container.append(text("span", "›", "path-arrow"));
    container.append(text("span", item.title));
  });
}

function renderFeedback(result) {
  const root = $("#feedback-content");
  root.replaceChildren();

  const head = document.createElement("div");
  head.className = "feedback-head";
  const headText = document.createElement("div");
  headText.append(
    text("p", "DIAGNOSIS / TRACEABLE RESPONSE", "section-kicker"),
    text("h3", result.diagnosis.knowledge_point),
    text("p", `${result.diagnosis.error_type} · 学生 ${result.student_id}`)
  );
  head.append(
    headText,
    text("div", `${Math.round(result.diagnosis.confidence * 100)}%`, "confidence")
  );
  root.append(head);

  root.append(text("p", result.observation, "observation"));

  const path = document.createElement("div");
  path.className = "path-strip";
  root.append(path);

  const hintSection = document.createElement("section");
  hintSection.className = "feedback-section";
  hintSection.append(text("h4", "提示阶梯"));
  const hintList = document.createElement("ol");
  hintList.className = "numbered-list";
  result.hint_ladder.forEach((hint, index) => {
    const item = text("li", hint);
    item.dataset.index = String(index + 1);
    hintList.append(item);
  });
  hintSection.append(hintList);
  root.append(hintSection);

  const checkSection = document.createElement("section");
  checkSection.className = "feedback-section";
  checkSection.append(text("h4", "先回答这些问题"));
  const checkList = document.createElement("ul");
  checkList.className = "check-list";
  result.self_check.forEach((item) => checkList.append(text("li", item)));
  checkSection.append(checkList);
  root.append(checkSection);

  const evidenceSection = document.createElement("section");
  evidenceSection.className = "feedback-section";
  evidenceSection.append(text("h4", "证据卡"));
  const cards = document.createElement("div");
  cards.className = "evidence-cards";
  result.evidence_cards.forEach((card) => {
    const article = document.createElement("article");
    article.className = "evidence-card";
    article.append(
      text("strong", card.title),
      text("p", card.detail),
      text("small", `${card.source} · ${card.strength}`)
    );
    cards.append(article);
  });
  evidenceSection.append(cards);
  root.append(evidenceSection);

  const reviewSection = document.createElement("section");
  reviewSection.className = "feedback-section";
  reviewSection.append(text("h4", "提交前复核"));
  const reviewList = document.createElement("ul");
  reviewList.className = "check-list";
  result.review_checklist.forEach((item) => reviewList.append(text("li", item)));
  reviewSection.append(reviewList);
  root.append(reviewSection);

  const noteSection = document.createElement("section");
  noteSection.className = "feedback-section";
  noteSection.append(text("h4", "使用边界"));
  const notes = document.createElement("div");
  notes.className = "policy-list";
  result.policy_notes.forEach((item) => notes.append(text("p", item)));
  noteSection.append(notes);
  root.append(noteSection);

  root.append(
    text(
      "div",
      `事件 ${result.event_id} · 记录摘要 ${result.provenance.record_digest}`,
      "provenance"
    )
  );
  $("#empty-state").hidden = true;
  root.hidden = false;
  $("#feedback-stage").classList.remove("empty-state");
}

async function submitFeedback() {
  const button = $("#feedback-button");
  const message = $("#form-message");
  message.textContent = "";
  button.disabled = true;
  try {
    const response = await fetch("/api/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        student_id: $("#student-id").value || "S-ANON",
        code: $("#code-input").value,
        error: $("#error-input").value,
        use_optional_model: $("#use-model").checked,
      }),
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || "请求失败");
    renderFeedback(body);
  } catch (error) {
    message.textContent = `未能生成反馈：${error.message}`;
  } finally {
    button.disabled = false;
  }
}

$("#feedback-button").addEventListener("click", submitFeedback);

function percent(value) {
  return `${Math.round(Number(value || 0) * 100)}%`;
}

function renderAnalytics(data) {
  $("#metric-events").textContent = data.total_events;
  $("#metric-resolution").textContent = percent(data.resolution_rate);
  $("#metric-review").textContent = percent(data.review_rate);
  $("#metric-high-hint").textContent = percent(data.high_hint_rate);
  $("#pulse-interpretation").textContent = data.interpretation;
  $("#synthetic-banner").hidden = true;
  $("#mode-label").textContent = "课程教学过程";

  const maxError = Math.max(1, ...data.error_hotspots.map((item) => item.count));
  const chart = $("#error-chart");
  chart.replaceChildren();
  data.error_hotspots.forEach((item) => {
    const row = document.createElement("div");
    row.className = "bar-row";
    const label = text("span", item.name);
    const track = document.createElement("div");
    track.className = "bar-track";
    const fill = document.createElement("div");
    fill.className = "bar-fill";
    fill.style.width = `${Math.max(5, (item.count / maxError) * 100)}%`;
    track.append(fill);
    row.append(label, track, text("span", String(item.count)));
    chart.append(row);
  });

  const knowledge = $("#knowledge-list");
  knowledge.replaceChildren();
  data.knowledge_hotspots.forEach((item) => {
    const row = document.createElement("div");
    row.className = "knowledge-item";
    row.append(text("span", item.name), text("span", String(item.count)));
    knowledge.append(row);
  });

  const table = $("#student-table");
  table.replaceChildren();
  data.students.forEach((student) => {
    const row = document.createElement("tr");
    const riskClass =
      student.risk_level === "关注"
        ? "risk"
        : student.risk_level === "观察"
          ? "risk observe"
          : "risk normal";
    const studentCell = document.createElement("td");
    studentCell.append(text("span", student.student_id, riskClass));
    row.append(
      studentCell,
      text("td", String(student.events)),
      text("td", percent(student.resolution_rate)),
      text("td", percent(student.review_rate)),
      text("td", percent(student.high_hint_rate)),
      text("td", student.reasons.join("、") || "无")
    );
    table.append(row);
  });
}

async function loadAnalytics() {
  try {
    const response = await fetch("/api/analytics");
    if (!response.ok) throw new Error("汇总读取失败");
    renderAnalytics(await response.json());
  } catch (error) {
    $("#pulse-interpretation").textContent = error.message;
  }
}

async function loadCourse() {
  try {
    const response = await fetch("/api/course");
    if (!response.ok) throw new Error("课程图谱读取失败");
    const data = await response.json();
    $("#graph-count").textContent = `${data.node_count} 个节点`;
    const list = $("#chapter-list");
    list.replaceChildren();
    data.chapters.forEach((chapter, index) => {
      const card = document.createElement("article");
      card.className = "chapter-card";
      card.append(
        text("span", `CH ${String(index + 1).padStart(2, "0")}`),
        text("strong", chapter.title)
      );
      list.append(card);
    });
  } catch (error) {
    $("#graph-count").textContent = error.message;
  }
}

loadAnalytics();
loadCourse();

