# 二次开发指引

## 接入课程平台

将平台事件映射到`EventStore.add_event`需要的字段。建议先导入一个班级、一个教学周期，检查匿名化与字段完整性，再扩大范围。

## 增加知识图谱

复制`data/course_graph.json`的结构，为每个节点填写：

- 唯一标识与标题。
- 所属章节与先修节点。
- 关键词、常见错误和教学依据。
- 数据来源。

节点可由课程大纲自动生成，但必须经教师复核后再进入正式版本。

## 增加诊断规则

在`yizhou_lab/diagnosis.py`中加入错误模式。规则只负责定位候选知识点，不能直接形成成绩。

## 接入模型

设置以下环境变量后，界面中的可选模型开关才会生效：

```bash
export YIZHOU_LLM_BASE_URL="https://your-endpoint/v1"
export YIZHOU_LLM_API_KEY="..."
export YIZHOU_LLM_MODEL="your-model"
```

不要把密钥写入仓库。

## 增加实验评价

在课程图谱的`rubrics`中加入实验量规。数据分析实验建议包含问题定义、数据处理、方法选择、结果验证、可复现性和AI使用声明。

