from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class CurriculumGraph:
    def __init__(self, path: Path):
        self.path = path
        self._graph = json.loads(path.read_text(encoding="utf-8"))
        self._nodes = {node["id"]: node for node in self._graph["nodes"]}

    def node(self, node_id: str) -> dict[str, Any] | None:
        return self._nodes.get(node_id)

    def prerequisites(self, node_id: str) -> list[dict[str, str]]:
        node = self.node(node_id)
        if not node:
            return []
        return [
            {"id": item, "title": self._nodes[item]["title"]}
            for item in node.get("prerequisites", [])
            if item in self._nodes
        ]

    def find_by_error(self, error_type: str, code: str = "") -> str:
        tokens = f"{error_type} {code}".lower()
        scored: list[tuple[int, str]] = []
        for node in self._nodes.values():
            score = 0
            for keyword in node.get("keywords", []):
                if keyword.lower() in tokens:
                    score += 3
            if error_type in node.get("errors", []):
                score += 5
            if score:
                scored.append((score, node["id"]))
        if not scored:
            return "python-basics"
        return max(scored)[1]

    def knowledge_path(self, node_id: str) -> list[dict[str, str]]:
        result: list[dict[str, str]] = []
        seen: set[str] = set()
        current: str | None = node_id
        while current and current not in seen:
            seen.add(current)
            node = self.node(current)
            if not node:
                break
            result.append({"id": node["id"], "title": node["title"]})
            current = node.get("parent")
        return list(reversed(result))

    def summary(self) -> dict[str, Any]:
        return {
            "course": self._graph["course"],
            "node_count": len(self._nodes),
            "chapters": [
                node
                for node in self._nodes.values()
                if node.get("kind") == "chapter"
            ],
            "data_policy": self._graph["data_policy"],
        }

    def rubric(self, case_id: str) -> dict[str, Any] | None:
        return self._graph.get("rubrics", {}).get(case_id)

