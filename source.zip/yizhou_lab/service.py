from __future__ import annotations

import json
import mimetypes
import re
import secrets
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .analytics import summarize
from .curriculum import CurriculumGraph
from .llm import optional_chat
from .models import FeedbackRequest
from .storage import EventStore
from .tutor import generate_feedback


MAX_BODY = 1_000_000


class Application:
    def __init__(self, root: Path, db_path: Path):
        self.root = root
        self.web_root = root / "web"
        self.graph = CurriculumGraph(root / "data" / "course_graph.json")
        self.store = EventStore(db_path)

    def feedback(self, payload: dict[str, Any]) -> dict[str, Any]:
        request = FeedbackRequest(
            student_id=str(payload.get("student_id", "S-ANON")).strip()[:32] or "S-ANON",
            code=str(payload.get("code", ""))[:20_000],
            error=str(payload.get("error", ""))[:10_000],
            intent=str(payload.get("intent", ""))[:2_000],
            course_id=str(payload.get("course_id", "python-data"))[:64],
        )
        external_answer = None
        if payload.get("use_optional_model"):
            external_answer = optional_chat(
                [
                    {
                        "role": "system",
                        "content": (
                            "你是编程课程的辅助诊断器。只给追问、自查点与最小修改方向，"
                            "不提供可直接提交的完整答案。输出不超过180字。"
                        ),
                    },
                    {
                        "role": "user",
                        "content": f"代码：{request.code}\n报错：{request.error}",
                    },
                ]
            )
        result = generate_feedback(request, self.graph, external_answer)
        event_id = self.store.add_event(
            {
                "student_id": result.student_id,
                "course_id": request.course_id,
                "function_name": "socratic-repair",
                "knowledge_point": result.diagnosis.knowledge_point,
                "error_type": result.diagnosis.error_type,
                "hint_level": 2,
                "resolved": False,
                "review_confirmed": False,
                "ai_used": True,
                "data_origin": "LIVE_INPUT",
                "payload": {
                    "diagnosis": result.diagnosis.to_dict(),
                    "provenance": result.provenance,
                },
            }
        )
        body = result.to_dict()
        body["event_id"] = event_id
        body["data_origin"] = "LIVE_INPUT"
        return body

    def analytics(self) -> dict[str, Any]:
        return summarize(self.store.list_events())


def make_handler(app: Application) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        server_version = "YizhouLab/0.6"

        def log_message(self, fmt: str, *args: Any) -> None:
            print(f"[yizhou] {self.address_string()} {fmt % args}")

        def _json(self, payload: Any, status: int = 200) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0"))
            if length > MAX_BODY:
                raise ValueError("request body too large")
            raw = self.rfile.read(length)
            return json.loads(raw.decode("utf-8")) if raw else {}

        def do_GET(self) -> None:
            path = urlparse(self.path).path
            if path == "/api/health":
                self._json(
                    {
                        "status": "ok",
                        "version": "0.6.0",
                        "storage": str(app.store.path),
                    }
                )
                return
            if path == "/api/course":
                self._json(app.graph.summary())
                return
            if path == "/api/analytics":
                self._json(app.analytics())
                return
            if path == "/api/export":
                export_dir = app.root / "exports"
                export_dir.mkdir(exist_ok=True)
                target = export_dir / f"evidence-{secrets.token_hex(4)}.json"
                app.store.export(target)
                body = target.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header(
                    "Content-Disposition",
                    f'attachment; filename="{target.name}"',
                )
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if path.startswith("/api/"):
                self._json({"error": "not found"}, HTTPStatus.NOT_FOUND)
                return
            self._static(path)

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            path = parsed.path
            if path == "/api/snapshot":
                self._snapshot(parsed.query)
                return
            try:
                payload = self._body()
            except (ValueError, json.JSONDecodeError) as exc:
                self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
                return
            if path == "/api/feedback":
                try:
                    self._json(app.feedback(payload), HTTPStatus.CREATED)
                except Exception as exc:
                    self._json(
                        {"error": f"feedback failed: {exc}"},
                        HTTPStatus.INTERNAL_SERVER_ERROR,
                    )
                return
            self._json({"error": "not found"}, HTTPStatus.NOT_FOUND)

        def _snapshot(self, query: str) -> None:
            from urllib.parse import parse_qs

            requested = parse_qs(query).get("name", ["screen"])[0]
            safe_name = re.sub(r"[^A-Za-z0-9._-]+", "-", requested)
            if not safe_name.lower().endswith(".png"):
                safe_name += ".png"
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 16_000_000:
                self._json({"error": "invalid snapshot size"}, HTTPStatus.BAD_REQUEST)
                return
            body = self.rfile.read(length)
            target = app.root / "docs" / "screenshots" / safe_name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(body)
            self._json({"saved": str(target), "bytes": len(body)})

        def _static(self, request_path: str) -> None:
            relative = "index.html" if request_path == "/" else request_path.lstrip("/")
            target = (app.web_root / relative).resolve()
            if app.web_root.resolve() not in target.parents and target != app.web_root.resolve():
                self._json({"error": "invalid path"}, HTTPStatus.BAD_REQUEST)
                return
            if not target.is_file():
                target = app.web_root / "index.html"
            content = target.read_bytes()
            content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
            self.send_response(200)
            self.send_header("Content-Type", f"{content_type}; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)

    return Handler


def serve(root: Path, db_path: Path, host: str, port: int) -> None:
    app = Application(root, db_path)
    server = ThreadingHTTPServer((host, port), make_handler(app))
    print(f"Yizhou V6 running at http://{host}:{port}")
    print(f"SQLite: {db_path}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()

