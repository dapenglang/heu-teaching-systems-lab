from __future__ import annotations

import re
from dataclasses import dataclass

from .curriculum import CurriculumGraph
from .models import Diagnosis


@dataclass(frozen=True, slots=True)
class Rule:
    error_type: str
    pattern: str
    note: str
    signals: tuple[str, ...]


RULES = (
    Rule(
        "KeyError",
        r"KeyError",
        "字典键不存在，常见原因是计数前没有初始化。",
        ("dictionary", "missing-key"),
    ),
    Rule(
        "IndentationError",
        r"IndentationError",
        "缩进结构不完整，先检查代码块边界与混合空格。",
        ("indentation", "block"),
    ),
    Rule(
        "UnicodeDecodeError",
        r"UnicodeDecodeError",
        "文本编码不一致，需要先确认源文件编码。",
        ("encoding", "file"),
    ),
    Rule(
        "FileNotFoundError",
        r"FileNotFoundError",
        "输入路径没有被程序找到，先验证工作目录和文件名。",
        ("path", "file"),
    ),
    Rule(
        "ModuleNotFoundError",
        r"(ModuleNotFoundError|ImportError)",
        "依赖没有安装或导入名称不正确。",
        ("dependency", "import"),
    ),
    Rule(
        "IndexError",
        r"IndexError",
        "访问位置超出序列范围，需要检查长度和边界。",
        ("index", "boundary"),
    ),
    Rule(
        "TypeError",
        r"TypeError",
        "值的类型与当前操作不匹配，先打印类型和形状。",
        ("type", "operation"),
    ),
    Rule(
        "ValueError",
        r"ValueError",
        "输入值可以被解析但不符合运算约束。",
        ("value", "constraint"),
    ),
)


def classify(code: str, error: str) -> tuple[str, float, list[str]]:
    haystack = f"{error}\n{code}"
    signals: list[str] = []
    matches: list[str] = []
    for rule in RULES:
        if re.search(rule.pattern, haystack, flags=re.IGNORECASE):
            matches.append(rule.error_type)
            signals.extend(rule.signals)
    if matches:
        confidence = 0.94 if len(matches) == 1 else 0.86
        return matches[0], confidence, sorted(set(signals))
    if "assert" in haystack.lower() or "结果不对" in haystack:
        return "ResultMismatch", 0.72, ["expected-output", "verification"]
    if "traceback" in haystack.lower():
        return "UnknownRuntimeError", 0.65, ["traceback"]
    return "NoErrorProvided", 0.55, ["reflection"]


def diagnose(
    graph: CurriculumGraph,
    code: str,
    error: str,
) -> Diagnosis:
    error_type, confidence, signals = classify(code, error)
    node_id = graph.find_by_error(error_type, f"{code}\n{error}")
    node = graph.node(node_id) or {
        "title": "Python基础与运行环境",
        "prerequisites": [],
    }
    boundary = "诊断依据当前代码与报错文本，未执行代码。"
    if error_type == "NoErrorProvided":
        boundary = "没有可识别的报错，当前判断只能作为学习线索。"
    return Diagnosis(
        error_type=error_type,
        knowledge_point_id=node_id,
        knowledge_point=node["title"],
        confidence=confidence,
        signals=signals,
        prerequisite_ids=[item["id"] for item in graph.prerequisites(node_id)],
        boundary_note=boundary,
    )

