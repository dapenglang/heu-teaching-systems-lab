"""Yizhou V6: local-first, evidence-oriented programming tutor."""

__version__ = "0.6.0"

