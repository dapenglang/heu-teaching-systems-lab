from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analytics import summarize
from .curriculum import CurriculumGraph
from .models import FeedbackRequest
from .service import serve
from .storage import EventStore
from .tutor import generate_feedback


ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DB = ROOT / "var" / "yizhou.sqlite3"


def main() -> None:
    parser = argparse.ArgumentParser(prog="yizhou")
    sub = parser.add_subparsers(dest="command", required=True)

    serve_parser = sub.add_parser("serve", help="start the local web application")
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8765)
    serve_parser.add_argument("--db", type=Path, default=DB)

    feedback_parser = sub.add_parser("feedback", help="generate one diagnostic response")
    feedback_parser.add_argument("--student-id", default="S-ANON")
    feedback_parser.add_argument("--code", default="")
    feedback_parser.add_argument("--error", default="")
    feedback_parser.add_argument("--intent", default="")

    export_parser = sub.add_parser("export", help="export local event evidence")
    export_parser.add_argument("--output", type=Path, default=ROOT / "exports" / "evidence.json")
    export_parser.add_argument("--db", type=Path, default=DB)

    analytics_parser = sub.add_parser("analytics", help="print class learning pulse")
    analytics_parser.add_argument("--db", type=Path, default=DB)

    args = parser.parse_args()
    if args.command == "serve":
        serve(ROOT, args.db, args.host, args.port)
    elif args.command == "feedback":
        graph = CurriculumGraph(DATA / "course_graph.json")
        request = FeedbackRequest(
            student_id=args.student_id,
            code=args.code,
            error=args.error,
            intent=args.intent,
        )
        print(
            json.dumps(
                generate_feedback(request, graph).to_dict(),
                ensure_ascii=False,
                indent=2,
            )
        )
    elif args.command == "export":
        store = EventStore(args.db)
        store.export(args.output)
        store.export_csv(args.output.with_suffix(".csv"))
        print(f"exported {args.output}")
    elif args.command == "analytics":
        store = EventStore(args.db)
        print(
            json.dumps(
                summarize(store.list_events()),
                ensure_ascii=False,
                indent=2,
            )
        )


if __name__ == "__main__":
    main()

