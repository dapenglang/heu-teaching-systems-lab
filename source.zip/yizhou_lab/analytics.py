from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any


def _ratio(part: int, total: int) -> float:
    return round(part / total, 4) if total else 0.0


def summarize(events: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(events)
    students = {event["student_id"] for event in events}
    resolved = sum(bool(event["resolved"]) for event in events)
    confirmed = sum(bool(event["review_confirmed"]) for event in events)
    high_hint = sum(int(event["hint_level"]) >= 3 for event in events)
    origin_counter = Counter(event["data_origin"] for event in events)

    errors = Counter(event["error_type"] for event in events)
    knowledge = Counter(event["knowledge_point"] for event in events)
    by_student: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for event in events:
        by_student[event["student_id"]].append(event)

    student_rows: list[dict[str, Any]] = []
    for student_id, items in by_student.items():
        item_total = len(items)
        item_resolved = sum(bool(item["resolved"]) for item in items)
        item_confirmed = sum(bool(item["review_confirmed"]) for item in items)
        item_high_hint = sum(int(item["hint_level"]) >= 3 for item in items)
        score = (
            (1 - _ratio(item_resolved, item_total)) * 0.5
            + (1 - _ratio(item_confirmed, item_total)) * 0.3
            + _ratio(item_high_hint, item_total) * 0.2
        )
        reasons: list[str] = []
        if _ratio(item_resolved, item_total) < 0.6:
            reasons.append("问题解决率偏低")
        if _ratio(item_confirmed, item_total) < 0.55:
            reasons.append("复核记录不足")
        if _ratio(item_high_hint, item_total) > 0.45:
            reasons.append("高提示依赖")
        level = "关注" if score >= 0.45 else "观察" if score >= 0.25 else "正常"
        student_rows.append(
            {
                "student_id": student_id,
                "events": item_total,
                "resolution_rate": _ratio(item_resolved, item_total),
                "review_rate": _ratio(item_confirmed, item_total),
                "high_hint_rate": _ratio(item_high_hint, item_total),
                "risk_score": round(score, 3),
                "risk_level": level,
                "reasons": reasons,
            }
        )
    student_rows.sort(
        key=lambda row: (row["risk_score"], -row["events"], row["student_id"]),
        reverse=True,
    )

    return {
        "total_events": total,
        "student_count": len(students),
        "resolution_rate": _ratio(resolved, total),
        "review_rate": _ratio(confirmed, total),
        "high_hint_rate": _ratio(high_hint, total),
        "origins": dict(origin_counter),
        "error_hotspots": [
            {"name": name, "count": count}
            for name, count in errors.most_common(8)
        ],
        "knowledge_hotspots": [
            {"name": name, "count": count}
            for name, count in knowledge.most_common(8)
        ],
        "students": student_rows[:12],
        "has_synthetic": origin_counter.get("SYNTHETIC_DEMO", 0) > 0,
        "interpretation": (
            "当前汇总用于检查知识点定位、提示与复核流程。"
            if origin_counter.get("SYNTHETIC_DEMO", 0)
            else "当前汇总来自已导入事件，仍需结合授权、样本量和统计口径解释。"
        ),
    }

