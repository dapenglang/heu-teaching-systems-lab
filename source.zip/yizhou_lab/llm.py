from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any


def optional_chat(messages: list[dict[str, str]]) -> str | None:
    """Call an OpenAI-compatible endpoint when explicitly configured.

    The default application remains deterministic and offline. Set:
    YIZHOU_LLM_BASE_URL, YIZHOU_LLM_API_KEY and YIZHOU_LLM_MODEL.
    """

    base_url = os.getenv("YIZHOU_LLM_BASE_URL", "").rstrip("/")
    api_key = os.getenv("YIZHOU_LLM_API_KEY", "")
    model = os.getenv("YIZHOU_LLM_MODEL", "")
    if not base_url or not api_key or not model:
        return None

    body = json.dumps(
        {
            "model": model,
            "messages": messages,
            "temperature": 0.2,
        },
        ensure_ascii=False,
    ).encode("utf-8")
    request = urllib.request.Request(
        f"{base_url}/chat/completions",
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            payload: dict[str, Any] = json.loads(response.read().decode("utf-8"))
        return payload["choices"][0]["message"]["content"]
    except (urllib.error.URLError, KeyError, TimeoutError, json.JSONDecodeError):
        return None

