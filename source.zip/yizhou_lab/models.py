from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class FeedbackRequest:
    student_id: str
    code: str
    error: str = ""
    intent: str = ""
    course_id: str = "python-data"


@dataclass(slots=True)
class Diagnosis:
    error_type: str
    knowledge_point_id: str
    knowledge_point: str
    confidence: float
    signals: list[str] = field(default_factory=list)
    prerequisite_ids: list[str] = field(default_factory=list)
    boundary_note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class EvidenceCard:
    title: str
    detail: str
    source: str
    strength: str = "teaching-design"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class FeedbackResult:
    student_id: str
    diagnosis: Diagnosis
    observation: str
    self_check: list[str]
    hint_ladder: list[str]
    review_checklist: list[str]
    evidence_cards: list[EvidenceCard]
    policy_notes: list[str]
    provenance: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "student_id": self.student_id,
            "diagnosis": self.diagnosis.to_dict(),
            "observation": self.observation,
            "self_check": self.self_check,
            "hint_ladder": self.hint_ladder,
            "review_checklist": self.review_checklist,
            "evidence_cards": [card.to_dict() for card in self.evidence_cards],
            "policy_notes": self.policy_notes,
            "provenance": self.provenance,
        }

