from __future__ import annotations

from .curriculum import CurriculumGraph
from .diagnosis import diagnose
from .models import EvidenceCard, FeedbackRequest, FeedbackResult
from .provenance import provenance


CHECKS = {
    "KeyError": [
        "计数对象在第一次写入前是否已经初始化？",
        "当前键是否真实存在于数据中？",
        "如果键不存在，程序应该创建它还是跳过？",
    ],
    "IndentationError": [
        "冒号后的代码块是否统一缩进？",
        "是否混用了Tab和空格？",
    ],
    "UnicodeDecodeError": [
        "源文件是什么编码？",
        "读取时是否显式指定了encoding？",
    ],
    "FileNotFoundError": [
        "程序实际从哪个工作目录读取文件？",
        "文件名、扩展名和大小写是否完全一致？",
    ],
    "ModuleNotFoundError": [
        "依赖是否安装到当前解释器？",
        "导入名是否与安装包名不同？",
    ],
    "IndexError": [
        "循环边界是否超过序列长度？",
        "空列表是否进入了下标访问？",
    ],
    "TypeError": [
        "操作两边的数据类型分别是什么？",
        "函数参数顺序和形状是否符合定义？",
    ],
    "ValueError": [
        "输入值是否满足函数要求？",
        "是否需要在转换前增加检查？",
    ],
}


HINTS = {
    "KeyError": [
        "先说出这一行想完成什么：读取已有计数，还是创建第一次计数？",
        "在写入前打印word与counts，确认键是否存在。",
        "用一个条件判断处理首次出现的键，再执行累加。",
        "把修改缩到一行，运行同一输入，并核对计数总和是否等于词数。",
    ],
    "IndentationError": [
        "先找到报错行前一个冒号。",
        "检查该代码块是否统一使用4个空格。",
        "只调整报错附近的结构，不重写整段程序。",
        "重新运行并确认程序进入了预期分支。",
    ],
    "UnicodeDecodeError": [
        "确认文件来源和编码。",
        "检查open是否显式指定编码。",
        "用错误的字节位置做小样本测试。",
        "重新读取后核对词数和首行内容。",
    ],
    "FileNotFoundError": [
        "先打印当前工作目录。",
        "单独测试文件路径是否存在。",
        "将路径解析与数据处理分开。",
        "运行后核对读到的行数和字段数。",
    ],
    "ModuleNotFoundError": [
        "确认当前Python解释器。",
        "检查包是否安装、名称是否一致。",
        "只修复导入，不改业务逻辑。",
        "再次运行并记录依赖版本。",
    ],
    "IndexError": [
        "打印序列长度和访问下标。",
        "检查循环终止条件。",
        "为初始状态增加边界保护。",
        "用空输入和一个元素输入各测一次。",
    ],
    "TypeError": [
        "打印相关变量的类型和值。",
        "定位类型第一次发生变化的位置。",
        "在边界处完成转换或校验。",
        "用正常值、空值和异常值各测一次。",
    ],
    "ValueError": [
        "确认触发异常的输入值。",
        "核对函数文档中的取值约束。",
        "在进入运算前增加合法性检查。",
        "用边界值验证错误提示是否清楚。",
    ],
}


DEFAULT_CHECKS = [
    "你预期这段代码输出什么？",
    "实际输出或报错发生在哪一行？",
    "最小可复现输入是什么？",
]

DEFAULT_HINTS = [
    "先用自己的话复述任务和当前现象。",
    "缩小输入，只保留触发问题的最少代码。",
    "在可能改变状态的位置打印中间结果。",
    "修改后重新运行，并解释结果为什么符合预期。",
]


def build_observation(request: FeedbackRequest, error_type: str) -> str:
    if error_type == "KeyError":
        return "程序把不存在的字典键当成已有键使用，问题更可能在计数初始化，而不是数据本身。"
    if error_type == "UnicodeDecodeError":
        return "读取文件时使用了与源文件不一致的编码，问题发生在文本进入业务逻辑之前。"
    if error_type == "FileNotFoundError":
        return "程序没有在当前工作目录找到目标文件，先确认路径，再检查数据处理。"
    if error_type == "IndentationError":
        return "代码块结构没有闭合到解释器可接受的位置，先修复作用域，再讨论算法。"
    if error_type == "ResultMismatch":
        return "代码可以运行，但输出与预期不一致，需要用最小样例定位数据变化。"
    if error_type == "NoErrorProvided":
        return "目前缺少可验证的报错或输出，先补上预期结果、实际结果和最小输入。"
    return f"当前更像{error_type}，但还需要通过中间输出确认触发条件。"


def generate_feedback(
    request: FeedbackRequest,
    graph: CurriculumGraph,
    external_answer: str | None = None,
) -> FeedbackResult:
    diagnosis = diagnose(graph, request.code, request.error)
    node = graph.node(diagnosis.knowledge_point_id) or {}
    path = graph.knowledge_path(diagnosis.knowledge_point_id)
    cards = [
        EvidenceCard(
            title="课程知识位置",
            detail=" > ".join(item["title"] for item in path),
            source=graph.path.name,
        ),
        EvidenceCard(
            title="错误信号",
            detail="、".join(diagnosis.signals) or "未提取到稳定信号",
            source="diagnosis.rules.v1",
        ),
        EvidenceCard(
            title="判断边界",
            detail=diagnosis.boundary_note,
            source="system-policy",
        ),
    ]
    if node.get("evidence"):
        cards.append(
            EvidenceCard(
                title="教学依据",
                detail=node["evidence"],
                source=node.get("source", "course-graph"),
            )
        )
    if external_answer:
        cards.append(
            EvidenceCard(
                title="外部模型建议",
                detail=external_answer,
                source="optional-model",
                strength="unverified",
            )
        )

    payload = {
        "student_id": request.student_id,
        "code": request.code,
        "error": request.error,
        "diagnosis": diagnosis.to_dict(),
        "hints": HINTS.get(diagnosis.error_type, DEFAULT_HINTS),
    }
    return FeedbackResult(
        student_id=request.student_id,
        diagnosis=diagnosis,
        observation=build_observation(request, diagnosis.error_type),
        self_check=CHECKS.get(diagnosis.error_type, DEFAULT_CHECKS),
        hint_ladder=HINTS.get(diagnosis.error_type, DEFAULT_HINTS),
        review_checklist=[
            "用同一最小输入重新运行。",
            "说明修改前后的差异。",
            "给出一个边界输入。",
            "确认AI没有替你完成未理解的部分。",
        ],
        evidence_cards=cards,
        policy_notes=[
            "不直接提供可提交的完整作业答案。",
            "低置信度诊断不会作为正式成绩依据。",
            "学生必须完成复核后才能写入解决事件。",
            "真实学生学习数据仅在授权、脱敏环境中使用。",
        ],
        provenance=provenance(
            payload,
            [
                str(graph.path),
                "diagnosis.rules.v1",
                "feedback.hint-ladder.v1",
            ],
        ),
    )

