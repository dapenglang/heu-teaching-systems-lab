from __future__ import annotations

import csv
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .provenance import digest


SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    student_id TEXT NOT NULL,
    course_id TEXT NOT NULL,
    function_name TEXT NOT NULL,
    knowledge_point TEXT NOT NULL,
    error_type TEXT NOT NULL,
    hint_level INTEGER NOT NULL,
    resolved INTEGER NOT NULL,
    review_confirmed INTEGER NOT NULL,
    ai_used INTEGER NOT NULL,
    data_origin TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    digest TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_student ON events(student_id);
CREATE INDEX IF NOT EXISTS idx_events_origin ON events(data_origin);
"""


class EventStore:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.executescript(SCHEMA)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def add_event(self, event: dict[str, Any]) -> int:
        row = {
            "created_at": event.get(
                "created_at",
                datetime.now(timezone.utc).isoformat(),
            ),
            "student_id": event["student_id"],
            "course_id": event.get("course_id", "python-data"),
            "function_name": event.get("function_name", "socratic-repair"),
            "knowledge_point": event.get("knowledge_point", "未定位"),
            "error_type": event.get("error_type", "Unknown"),
            "hint_level": int(event.get("hint_level", 1)),
            "resolved": int(bool(event.get("resolved", False))),
            "review_confirmed": int(bool(event.get("review_confirmed", False))),
            "ai_used": int(bool(event.get("ai_used", True))),
            "data_origin": event.get("data_origin", "teacher-import"),
            "payload_json": json.dumps(
                event.get("payload", {}),
                ensure_ascii=False,
                sort_keys=True,
            ),
            "digest": digest(event),
        }
        with self.connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO events (
                    created_at, student_id, course_id, function_name,
                    knowledge_point, error_type, hint_level, resolved,
                    review_confirmed, ai_used, data_origin, payload_json, digest
                ) VALUES (
                    :created_at, :student_id, :course_id, :function_name,
                    :knowledge_point, :error_type, :hint_level, :resolved,
                    :review_confirmed, :ai_used, :data_origin, :payload_json, :digest
                )
                """,
                row,
            )
            return int(cursor.lastrowid)

    def clear_origin(self, origin: str) -> int:
        with self.connect() as connection:
            cursor = connection.execute(
                "DELETE FROM events WHERE data_origin = ?",
                (origin,),
            )
            return int(cursor.rowcount)

    def list_events(self, origin: str | None = None) -> list[dict[str, Any]]:
        query = "SELECT * FROM events"
        params: tuple[Any, ...] = ()
        if origin:
            query += " WHERE data_origin = ?"
            params = (origin,)
        query += " ORDER BY created_at ASC, id ASC"
        with self.connect() as connection:
            rows = connection.execute(query, params).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["payload"] = json.loads(item.pop("payload_json"))
            item["resolved"] = bool(item["resolved"])
            item["review_confirmed"] = bool(item["review_confirmed"])
            item["ai_used"] = bool(item["ai_used"])
            result.append(item)
        return result

    def export(self, path: Path, origin: str | None = None) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        events = self.list_events(origin)
        envelope = {
            "schema": "yizhou.evidence-export.v1",
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "origin": origin or "all",
            "event_count": len(events),
            "events": events,
        }
        envelope["digest"] = digest(envelope)
        path.write_text(
            json.dumps(envelope, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def export_csv(self, path: Path, origin: str | None = None) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        events = self.list_events(origin)
        fields = [
            "created_at",
            "student_id",
            "course_id",
            "function_name",
            "knowledge_point",
            "error_type",
            "hint_level",
            "resolved",
            "review_confirmed",
            "ai_used",
            "data_origin",
            "digest",
        ]
        with path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for event in events:
                writer.writerow({key: event[key] for key in fields})

